# -*- coding: utf-8 -*-
"""AI Subtitle Generation button in the player and the subtitle window of the BN skin (skin.fentastic).

Pure Python (no Kodi modules): used by tools/make_build.py for new builds and by the service at start-up,
so boxes that update NovaTV from the repository get the button too (idempotent)."""
import os
import re

AI_RUN = 'RunPlugin(plugin://plugin.video.nova/?a=ai_subs_now)'
AI_LABEL = 'יצירת כתוביות AI'
MENU_RUN = 'RunPlugin(plugin://plugin.video.nova/?a=subs_menu)'
MENU_LABEL = 'כתוביות BN'


def apply(xml):
    """'AI Subtitle Generation' next to the subtitle buttons of every player style and in the subtitle window.
    Returns how many skin files were changed (0 = already there)."""
    n = 0
    item = ('\n\t<item>\n\t\t<label>%s</label>\n\t\t<icon>osd/fullscreen/buttons/subs3.png</icon>\n'
            '\t\t<onclick>%s</onclick>\n\t\t<visible>!VideoPlayer.Content(LiveTV)</visible>\n\t</item>') % (AI_LABEL, AI_RUN)
    # item-list players (advanced, netflix): right after "search subtitles"
    for fn, rx in (('Includes_VideoOsd.xml', r'(<item id="107">.*?</item>)'),
                   ('Includes_VideoOsd1.xml', r'(<item id="107">.*?</item>)'),
                   ('Includes_VideoOsd2.xml', r'(<item>\s*<label>חפש כתובית</label>.*?</item>)')):
        p = os.path.join(xml, fn)
        t = open(p, encoding='utf-8', newline='').read()
        if AI_RUN not in t:
            t, k = re.subn(rx, lambda m: m.group(1) + item, t, count=1, flags=re.S)
            assert k, 'subtitle item not found in ' + fn
            open(p, 'w', encoding='utf-8', newline='').write(t)
            n += 1
    # simple player: a button after the DarkSubs button
    p = os.path.join(xml, 'Includes_VideoOsd3.xml')
    t = open(p, encoding='utf-8', newline='').read()
    if AI_RUN not in t:
        btn = ('\n\t\t\t\t\t<control type="button" id="700452">\n\t\t\t\t\t\t<description>BN AI subtitles</description>\n'
               '\t\t\t\t\t\t<width>225</width>\n\t\t\t\t\t\t<height>76</height>\n\t\t\t\t\t\t<label>[B]AI[/B] כתוביות</label>\n'
               '\t\t\t\t\t\t<font>font12</font>\n\t\t\t\t\t\t<align>center</align>\n\t\t\t\t\t\t<aligny>center</aligny>\n'
               '\t\t\t\t\t\t<textcolor>grey_a</textcolor>\n\t\t\t\t\t\t<focusedcolor>button_focus</focusedcolor>\n'
               '\t\t\t\t\t\t<texturenofocus />\n\t\t\t\t\t\t<texturefocus />\n'
               '\t\t\t\t\t\t<onclick>%s</onclick>\n\t\t\t\t\t\t<visible>!VideoPlayer.Content(LiveTV)</visible>\n'
               '\t\t\t\t\t</control>') % AI_RUN
        t, k = re.subn(r'(<control type="button" id="700451">.*?</control>)', lambda m: m.group(1) + btn, t, count=1, flags=re.S)
        assert k, 'DarkSubs button not found'
        open(p, 'w', encoding='utf-8', newline='').write(t)
        n += 1
    # Kodi's subtitle window (the default "search subtitles" of the player): a button above the services list
    p = os.path.join(xml, 'DialogSubtitles.xml')
    t = open(p, encoding='utf-8', newline='').read()
    if AI_RUN not in t:
        btn = ('<control type="button" id="7160">\n\t\t\t\t\t<description>BN AI subtitles</description>\n'
               '\t\t\t\t\t<left>20</left>\n\t\t\t\t\t<top>120</top>\n\t\t\t\t\t<width>280</width>\n\t\t\t\t\t<height>60</height>\n'
               '\t\t\t\t\t<label>[B]%s[/B]</label>\n\t\t\t\t\t<font>font12</font>\n\t\t\t\t\t<align>center</align>\n'
               '\t\t\t\t\t<aligny>center</aligny>\n\t\t\t\t\t<textcolor>FFE8BE5A</textcolor>\n'
               '\t\t\t\t\t<texturefocus colordiffuse="button_focus">colors/white.png</texturefocus>\n'
               '\t\t\t\t\t<texturenofocus colordiffuse="30FFFFFF">colors/white.png</texturenofocus>\n'
               '\t\t\t\t\t<focusedcolor>black</focusedcolor>\n'
               '\t\t\t\t\t<onleft>120</onleft>\n\t\t\t\t\t<ondown>150</ondown>\n'
               '\t\t\t\t\t<onclick>%s</onclick>\n\t\t\t\t</control>\n\t\t\t\t') % (AI_LABEL, AI_RUN)
        assert '<control type="list" id="150">' in t and '<onup>150</onup>' in t
        t = t.replace('<control type="list" id="150">', btn + '<control type="list" id="150">', 1)
        t = t.replace('<onup>150</onup>', '<onup>7160</onup>', 1)
        open(p, 'w', encoding='utf-8', newline='').write(t)
        n += 1
    # Up from the results list reaches the AI button too (also for skins patched by 0.2.1)
    t = open(p, encoding='utf-8', newline='').read()
    old = '<control type="list" id="120">\n\t\t\t\t<top>50</top>\n\t\t\t\t<onup>false</onup>'
    if old in t:
        t = t.replace(old, old.replace('<onup>false</onup>', '<onup>7160</onup>'), 1)
        open(p, 'w', encoding='utf-8', newline='').write(t)
        n += 1
    n += _menu_button(xml)
    n += bn_player(xml)
    return n


def _menu_button(xml):
    """'כתוביות BN' (every track incl. AI, turn AI on by hand, generate, search, sync) right after the AI item"""
    n = 0
    item = ('\n\t<item>\n\t\t<label>%s</label>\n\t\t<icon>osd/fullscreen/buttons/subs.png</icon>\n'
            '\t\t<onclick>%s</onclick>\n\t</item>') % (MENU_LABEL, MENU_RUN)
    for fn in ('Includes_VideoOsd.xml', 'Includes_VideoOsd1.xml', 'Includes_VideoOsd2.xml'):
        p = os.path.join(xml, fn)
        t = open(p, encoding='utf-8', newline='').read()
        if MENU_RUN in t or AI_RUN not in t:
            continue
        i = t.index(AI_RUN)
        j = t.index('</item>', i) + len('</item>')
        t = t[:j] + item + t[j:]
        open(p, 'w', encoding='utf-8', newline='').write(t)
        n += 1
    p = os.path.join(xml, 'Includes_VideoOsd3.xml')
    t = open(p, encoding='utf-8', newline='').read()
    if MENU_RUN not in t and AI_RUN in t:
        btn = ('\n\t\t\t\t\t<control type="button" id="700453">\n\t\t\t\t\t\t<description>BN subtitles</description>\n'
               '\t\t\t\t\t\t<width>225</width>\n\t\t\t\t\t\t<height>76</height>\n\t\t\t\t\t\t<label>%s</label>\n'
               '\t\t\t\t\t\t<font>font12</font>\n\t\t\t\t\t\t<align>center</align>\n\t\t\t\t\t\t<aligny>center</aligny>\n'
               '\t\t\t\t\t\t<textcolor>grey_a</textcolor>\n\t\t\t\t\t\t<focusedcolor>button_focus</focusedcolor>\n'
               '\t\t\t\t\t\t<texturenofocus />\n\t\t\t\t\t\t<texturefocus />\n'
               '\t\t\t\t\t\t<onclick>%s</onclick>\n\t\t\t\t\t</control>') % (MENU_LABEL, MENU_RUN)
        i = t.index('<control type="button" id="700452">')
        j = t.index('</control>', i) + len('</control>')
        t = t[:j] + btn + t[j:]
        open(p, 'w', encoding='utf-8', newline='').write(t)
        n += 1
    return n


BN_OSD = 'Includes_VideoOsdBN.xml'
BN_INCLUDE = '<include condition="String.IsEqual(Skin.String(__chooseplayer),__bnplayer)">videosd_bn</include>'


def bn_player(xml):
    """the BN player style (one row of big buttons, name of the focused one, progress + times) - file shipped
    in resources/skin, registered in Includes.xml and selectable as __chooseplayer = __bnplayer"""
    n = 0
    for fn in (BN_OSD, 'Custom_1190_BNLiveBar.xml'):     # + the live-TV bar window (1.4.4)
        src = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'skin', fn)
        dst = os.path.join(xml, fn)
        body = open(src, encoding='utf-8', newline='').read()
        if not os.path.exists(dst) or open(dst, encoding='utf-8', newline='').read() != body:
            open(dst, 'w', encoding='utf-8', newline='').write(body)
            n += 1
    # icons -> the skin's own media folder (skin textures are looked up there)
    icons = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'skin', 'icons')
    media = os.path.join(os.path.dirname(os.path.normpath(xml)), 'media', 'bn')
    os.makedirs(media, exist_ok=True)
    for fn in os.listdir(icons):
        a, b = os.path.join(icons, fn), os.path.join(media, fn)
        data = open(a, 'rb').read()
        if not os.path.exists(b) or open(b, 'rb').read() != data:
            open(b, 'wb').write(data)
            n += 1
    p = os.path.join(xml, 'Includes.xml')
    t = open(p, encoding='utf-8', newline='').read()
    if BN_OSD not in t:
        i = t.index('<include file=')
        t = t[:i] + ('<include file="%s" />' % BN_OSD) + chr(10) + chr(9) + t[i:]
        open(p, 'w', encoding='utf-8', newline='').write(t)
        n += 1
    p = os.path.join(xml, 'VideoOSD.xml')
    t = open(p, encoding='utf-8', newline='').read()
    if BN_INCLUDE not in t:
        anchor = '>videosd4</include>'
        i = t.index(anchor) + len(anchor)
        t = t[:i] + chr(10) + chr(9) + BN_INCLUDE + ' <!-- נגן BN -->' + t[i:]
        open(p, 'w', encoding='utf-8', newline='').write(t)
        n += 1
    return n
